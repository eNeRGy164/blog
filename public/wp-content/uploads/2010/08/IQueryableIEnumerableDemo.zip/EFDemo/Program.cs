﻿using System;
using System.Data;
using System.Linq;

namespace EFDemo
{
    class Program
    {
        static void Main()
        {
            //
            // Use IntelliTrace to view th different SQL Statements
            //

            var entities = new DemoModelContainer();
            
            //
            // Generates a UNION ALL with 3 items
            //
            var countryIds = Enumerable.Range(1, 3);

            var query1 = from i in entities.Items
                        from c in i.Countries
                        join cid in countryIds on c.Id equals cid
                        select i;

            var items1 = query1.ToList();

            Console.WriteLine(items1.Count);



            //
            // Generates a UNION ALL with 50 items, too large for SQL to handle
            //
            countryIds = Enumerable.Range(1, 50);

            var query2 = from i in entities.Items
                        from c in i.Countries
                        join cid in countryIds on c.Id equals cid
                        select i;

            try
            {
                var items2 = query2.ToList();

                Console.WriteLine(items2.Count);
            }
            catch (EntityCommandExecutionException ex)
            {
                // Expected
                Console.WriteLine(ex.InnerException.Message);
            }



            //
            // Generates a WHERE IN with 3 items
            //
            countryIds = Enumerable.Range(1, 3);

            var query3 = from i in entities.Items
                        from c in i.Countries
                        where countryIds.Contains(c.Id)
                        select i;

            var items3 = query3.ToList();

            Console.WriteLine(items3.Count);



            //
            // Generates a WHERE IN with 50 items
            //
            countryIds = Enumerable.Range(1, 50);

            var query4 = from i in entities.Items
                         from c in i.Countries
                         where countryIds.Contains(c.Id)
                         select i;

            var items4 = query4.ToList();

            Console.WriteLine(items4.Count);
        }
    }
}
