
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, and Azure
-- --------------------------------------------------
-- Date Created: 08/26/2010 12:27:47
-- Generated from EDMX file: C:\Users\Michael.Hompus\documents\visual studio 2010\Projects\EFDemo\EFDemo\DemoModel.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [SqlDemoDatabase];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[FK_CountryItem_Country]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[CountryItem] DROP CONSTRAINT [FK_CountryItem_Country];
GO
IF OBJECT_ID(N'[dbo].[FK_CountryItem_Item]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[CountryItem] DROP CONSTRAINT [FK_CountryItem_Item];
GO
IF OBJECT_ID(N'[dbo].[FK_CountryRegion_Country]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[CountryRegion] DROP CONSTRAINT [FK_CountryRegion_Country];
GO
IF OBJECT_ID(N'[dbo].[FK_CountryRegion_Region]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[CountryRegion] DROP CONSTRAINT [FK_CountryRegion_Region];
GO
IF OBJECT_ID(N'[dbo].[FK_RegionItem_Region]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[RegionItem] DROP CONSTRAINT [FK_RegionItem_Region];
GO
IF OBJECT_ID(N'[dbo].[FK_RegionItem_Item]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[RegionItem] DROP CONSTRAINT [FK_RegionItem_Item];
GO

-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[Countries]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Countries];
GO
IF OBJECT_ID(N'[dbo].[Items]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Items];
GO
IF OBJECT_ID(N'[dbo].[Regions]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Regions];
GO
IF OBJECT_ID(N'[dbo].[CountryItem]', 'U') IS NOT NULL
    DROP TABLE [dbo].[CountryItem];
GO
IF OBJECT_ID(N'[dbo].[CountryRegion]', 'U') IS NOT NULL
    DROP TABLE [dbo].[CountryRegion];
GO
IF OBJECT_ID(N'[dbo].[RegionItem]', 'U') IS NOT NULL
    DROP TABLE [dbo].[RegionItem];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'Countries'
CREATE TABLE [dbo].[Countries] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Name] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'Items'
CREATE TABLE [dbo].[Items] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Name] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'Regions'
CREATE TABLE [dbo].[Regions] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Name] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'CountryItem'
CREATE TABLE [dbo].[CountryItem] (
    [Countries_Id] int  NOT NULL,
    [Items_Id] int  NOT NULL
);
GO

-- Creating table 'CountryRegion'
CREATE TABLE [dbo].[CountryRegion] (
    [Countries_Id] int  NOT NULL,
    [Regions_Id] int  NOT NULL
);
GO

-- Creating table 'RegionItem'
CREATE TABLE [dbo].[RegionItem] (
    [Regions_Id] int  NOT NULL,
    [Items_Id] int  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [Id] in table 'Countries'
ALTER TABLE [dbo].[Countries]
ADD CONSTRAINT [PK_Countries]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Items'
ALTER TABLE [dbo].[Items]
ADD CONSTRAINT [PK_Items]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Regions'
ALTER TABLE [dbo].[Regions]
ADD CONSTRAINT [PK_Regions]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Countries_Id], [Items_Id] in table 'CountryItem'
ALTER TABLE [dbo].[CountryItem]
ADD CONSTRAINT [PK_CountryItem]
    PRIMARY KEY NONCLUSTERED ([Countries_Id], [Items_Id] ASC);
GO

-- Creating primary key on [Countries_Id], [Regions_Id] in table 'CountryRegion'
ALTER TABLE [dbo].[CountryRegion]
ADD CONSTRAINT [PK_CountryRegion]
    PRIMARY KEY NONCLUSTERED ([Countries_Id], [Regions_Id] ASC);
GO

-- Creating primary key on [Regions_Id], [Items_Id] in table 'RegionItem'
ALTER TABLE [dbo].[RegionItem]
ADD CONSTRAINT [PK_RegionItem]
    PRIMARY KEY NONCLUSTERED ([Regions_Id], [Items_Id] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [Countries_Id] in table 'CountryItem'
ALTER TABLE [dbo].[CountryItem]
ADD CONSTRAINT [FK_CountryItem_Country]
    FOREIGN KEY ([Countries_Id])
    REFERENCES [dbo].[Countries]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [Items_Id] in table 'CountryItem'
ALTER TABLE [dbo].[CountryItem]
ADD CONSTRAINT [FK_CountryItem_Item]
    FOREIGN KEY ([Items_Id])
    REFERENCES [dbo].[Items]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_CountryItem_Item'
CREATE INDEX [IX_FK_CountryItem_Item]
ON [dbo].[CountryItem]
    ([Items_Id]);
GO

-- Creating foreign key on [Countries_Id] in table 'CountryRegion'
ALTER TABLE [dbo].[CountryRegion]
ADD CONSTRAINT [FK_CountryRegion_Country]
    FOREIGN KEY ([Countries_Id])
    REFERENCES [dbo].[Countries]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [Regions_Id] in table 'CountryRegion'
ALTER TABLE [dbo].[CountryRegion]
ADD CONSTRAINT [FK_CountryRegion_Region]
    FOREIGN KEY ([Regions_Id])
    REFERENCES [dbo].[Regions]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_CountryRegion_Region'
CREATE INDEX [IX_FK_CountryRegion_Region]
ON [dbo].[CountryRegion]
    ([Regions_Id]);
GO

-- Creating foreign key on [Regions_Id] in table 'RegionItem'
ALTER TABLE [dbo].[RegionItem]
ADD CONSTRAINT [FK_RegionItem_Region]
    FOREIGN KEY ([Regions_Id])
    REFERENCES [dbo].[Regions]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [Items_Id] in table 'RegionItem'
ALTER TABLE [dbo].[RegionItem]
ADD CONSTRAINT [FK_RegionItem_Item]
    FOREIGN KEY ([Items_Id])
    REFERENCES [dbo].[Items]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_RegionItem_Item'
CREATE INDEX [IX_FK_RegionItem_Item]
ON [dbo].[RegionItem]
    ([Items_Id]);
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------